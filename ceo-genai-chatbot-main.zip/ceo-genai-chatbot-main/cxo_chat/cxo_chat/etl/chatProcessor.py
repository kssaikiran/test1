import logging


class ChatProcessor:
    def __init__(self, config):
        self.config = config
        logging.info('Initialized ChatProcessor')
