import re
from bs4 import BeautifulSoup


def remove_non_ascii(text):
    return re.sub(r'[^\x00-\x7F]+', '', text)


def extract_text(html):

    # Extract text from HTML
    soup = BeautifulSoup(html, features="html.parser")
    text = soup.get_text()
    return text
