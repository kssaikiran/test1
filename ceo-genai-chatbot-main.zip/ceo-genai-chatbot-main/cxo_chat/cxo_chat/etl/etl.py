import logging
from cxo_chat.etl.fileProcessor import FileProcessor
from cxo_chat.etl.emailProcessor import EmailProcessor


class ETL:
    """
    Class for orchestrating the ETL process.
    """

    def __init__(self, config, services):
        logging.info('Initialized ETL')

        # initialize etl tools
        self.file_processor = FileProcessor(config, services)
        self.email_processor = EmailProcessor(config, services)

    def run(self):

        print('########################')
        print('#    DOWNLOAD PHASE    #')
        print('########################')
        print()

        # download emails
        emails_with_attachments = self.email_processor.download_emails()

        # download attachments
        self.file_processor.download_email_attachments(emails_with_attachments)

        # download one drive files
        self.file_processor.download_onedrive_files()

        # download shared files
        self.file_processor.download_shared_files()

        print()
        print('########################')
        print('#   PROCESSING PHASE   #')
        print('########################')
        print()

        # process emails
        self.email_processor.process_emails()

        # process files
        self.file_processor.process_files()
