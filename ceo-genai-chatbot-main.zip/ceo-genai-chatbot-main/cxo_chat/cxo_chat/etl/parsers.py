import io
import logging
from docx import Document
from pptx import Presentation


class WordParser:
    """
    Class to extract text from a Word file
    """
    def __init__(self, config):
        logging.info('Initialized WordParser')

    def process_bytes(self, file_bytes):

        # process file bytes
        with io.BytesIO(file_bytes) as f:
            d = Document(f)

        # extract text
        text = '\n'.join([p.text for p in d.paragraphs])

        return text


class TextParser:
    """
    Class to extract text from a txt file
    """
    def __init__(self, config):
        logging.info('Initialized WordParser')

    def process_bytes(self, file_bytes):

        # process file bytes
        with io.BytesIO(file_bytes) as f:
            text = f.read().decode('utf-8')

        return text


class PowerPointParser:
    """
    Class to extract text from a PowerPoint file
    """
    def __init__(self, config):
        logging.info('Initialized PowerPointParser')

    def process_bytes(self, file_bytes):

        # process file bytes
        with io.BytesIO(file_bytes) as f:
            deck = Presentation(f)

        # extract text
        text = '\n'.join([shape.text for slide in
                          deck.slides for shape in
                          slide.shapes if shape.has_text_frame])

        return text
