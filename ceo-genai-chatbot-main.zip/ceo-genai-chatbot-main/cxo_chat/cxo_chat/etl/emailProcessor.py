from tqdm import tqdm
import logging
from cxo_chat.etl.utils import remove_non_ascii, extract_text
from cxo_chat.etl.textSplitter import TextSplitter

# import db models
from cxo_chat.db.models import Email
from cxo_chat.db.models import EmailEmbedding


class EmailProcessor:
    def __init__(self, config, services):

        # copy config
        self.config = config

        # copy services
        self.services = services

        # text splitter is added to the email processor as
        # diferrent processors may have different splitters
        self.text_splitter = TextSplitter(config)
        logging.info('Initialized EmailProcessor')

    def download_emails(self):

        # get emails
        emails = self.services["microsoft_graph"].get_top_ten_emails()

        # filter out already processed emails
        emails = self.filter_emails(emails)

        # preprocessing
        emails = self.preprocess_emails(emails)

        # get emails with attachments
        emails_with_attachments = self.get_emails_with_attachments(emails)

        # embed and store email subjects and content
        self.store_emails(emails)

        return emails_with_attachments

    def process_emails(self):

        # get emails
        emails = Email.get_unprocessed_emails(self.services["cosmos_db"].session)

        # embed and store email subjects and content
        self.embed_and_store_emails(emails)

    def filter_emails(self, emails):

        # log before filtering
        n_emails = len(emails)
        logging.info(f'Before filtering processed emails {n_emails} detected')

        # filter out already processed emails
        emails = [email for email in emails['value'] if
                  not Email.exists(self.services["cosmos_db"].session, email['id'])]

        # log after filtering
        n_emails = len(emails)
        logging.info(f'After filtering processed emails {n_emails} remained')

        return emails

    def preprocess_emails(self, emails):

        #################
        # PREPROCESSING #
        #################

        # for each email flatten and preprocess email JSON
        for email in emails:

            # extract email body text
            email['content'] = extract_text(email['body']['content'])

            # remove ascii
            email['content'] = remove_non_ascii(email['content'])
            email['subject'] = remove_non_ascii(email['subject'])

            # serialize sender info
            email['sender_email'] = email['sender']['emailAddress']['address']
            email['sender_name'] = email['sender']['emailAddress']['name']
            email['processed'] = False

            # remove unnecessary fields
            email.pop('body', None)
            email.pop('sender', None)

            # remove unnecessary $ fields
            fields_to_remove = [key for key in email.keys() if key.startswith('@')]
            for field in fields_to_remove:
                email.pop(field, None)

        n_emails = len(emails)
        logging.info(f'Preprocessed {n_emails} emails')
        return emails

    def get_emails_with_attachments(self, emails):
        # get emails with attachments
        return [(email['id'], email['webLink']) for email in emails if email['hasAttachments']]

    def store_emails(self, emails):
        # store each email in DB
        print('Downloading and stoing emails:')
        for email in tqdm(emails):
            obj = Email(**email)
            obj.save(self.services["cosmos_db"].session)

    def embed_and_store_emails(self, emails):

        # for each email flatten and preprocess email JSON
        print('Processing of the emails:')
        for email in tqdm(emails):

            ###########################
            # embed the email subject #
            ###########################

            self.embed_chunk(
                chunk=email.subject,
                chunk_id=email.id + '_subject',
                email_id=email.id
            )

            ###########################
            # embed the email content #
            ###########################

            # split the email content into chunks
            docs = self.text_splitter.split([email.content])
            logging.info(f'Split email {email.id} into {len(docs)} chunks')

            # embed each chunk
            for ind, doc in enumerate(docs):

                self.embed_chunk(
                    chunk=doc.page_content,
                    chunk_id=email.id + '_content_' + str(ind),
                    email_id=email.id
                )

            # change processed flag and upate email obj in DB
            obj = Email.get(self.services["cosmos_db"].session, email.id)
            obj.processed = True
            obj.update(self.services["cosmos_db"].session)

        n_emails = len(emails)
        logging.info(f'Processed {n_emails} emails')

    def embed_chunk(self, chunk, chunk_id, email_id):

        # embed the email subject
        embedding = self.services["azure_openai"].embeddings.embed_query(chunk)

        # write it to the database
        obj = EmailEmbedding(
            chunk_id=chunk_id,
            email_id=email_id,
            chunk=chunk,
            embedding=embedding
        )
        obj.save(self.services["cosmos_db"].session)
