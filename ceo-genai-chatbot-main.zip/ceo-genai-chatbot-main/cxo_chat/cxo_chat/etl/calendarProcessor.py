import logging


class CalendarProcessor:
    def __init__(self, config):
        self.config = config
        logging.info('Initialized CalendarProcessor')
