import logging


class Synchronizer:
    def __init__(self, config):
        self.config = config
        logging.info('Initialized Synchronizer')
