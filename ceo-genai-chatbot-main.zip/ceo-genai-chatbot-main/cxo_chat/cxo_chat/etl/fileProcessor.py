import os
import logging
from tqdm import tqdm
from cxo_chat.etl.textSplitter import TextSplitter
from cxo_chat.db.models import File, FileEmbedding
from cxo_chat.etl.parsers import WordParser, PowerPointParser, TextParser


class FileProcessor:
    """
    Class for processing files (processing of email attachments,
    downloading, preprocessing, parsing, embedding and storage of OneDrive files)
    """

    def __init__(self, config, services):

        # copy config
        self.config = config

        # copy services
        self.services = services

        # init text splitter
        self.text_splitter = TextSplitter(config)

        # init custom parsers
        self.word_parser = WordParser(config)
        self.powerpoint_parser = PowerPointParser(config)
        self.text_parser = TextParser(config)

        # log
        logging.info('Initialized FileProcessor')

    def download_email_attachments(self, emails_with_attachments):

        print('Downloading email attachments:')
        for (email_id, webLink) in emails_with_attachments:

            # get attachments
            files = self.services["microsoft_graph"].get_attachments(email_id)['value']

            # filter out already processed files
            files = self.filter_files(files)

            # process files
            self.store_file_batch(files, email_id=email_id, webUrl=webLink, origin='email')

    def download_onedrive_files(self):

        # process all file types
        for file_type in self.config['ETL']['VALID_FILE_EXTENSIONS']:

            # extract files
            files = self.services["microsoft_graph"].get_top_ten_onedrive_files(
                format=file_type)['value']

            # filter out already processed files
            files = self.filter_files(files)

            # process files
            print(f'Downloading files of type "{file_type}":')
            self.store_file_batch(files, origin='onedrive')

    def download_shared_files(self):

        # extract files
        files = self.services["microsoft_graph"].get_top_ten_shared_files()['value']

        # preprocess files
        files = self.preprocess_shared_files(files)

        # filter out already processed files
        files = self.filter_files(files)

        # process files
        print('Downloading shared files:')
        self.store_file_batch(files, origin='shared')

    def process_files(self):

        # extract unprocessed files from DB
        files = File.get_unprocessed_files(self.services["cosmos_db"].session)

        # process files
        print('Processing of the files:')
        self.process_file_batch(files)

    def preprocess_shared_files(self, files):
        # look only in remote item value
        return [file["remoteItem"] for file in files]

    def filter_files(self, files):

        # log before filtering
        n_files = len(files)
        logging.info(f'Before filtering processed files {n_files} detected')

        # filter out already processed files
        files = [file for file in files if not
                 File.exists(self.services["cosmos_db"].session, file['id'])]

        # log after filtering
        n_files = len(files)
        logging.info(f'After filtering processed files {n_files} remained')

        return files

    def store_file_batch(self, files, email_id=None, webUrl=None, origin=None):

        # log
        n_files = len(files)
        logging.info(f'Downloading and storing {n_files} OneDrive files')

        for file in tqdm(files):
            if self.validate_file(file):
                self.store_file(file=file,
                                email_id=email_id,
                                webUrl=webUrl,
                                origin=origin)

    def process_file_batch(self, files):

        # log
        n_files = len(files)
        logging.info(f'Processing {n_files} OneDrive files')

        for file in tqdm(files):
            self.process_file(file=file,
                              filetype=file.name.split('.')[-1])

    def validate_file(self, file):

        # check if file is a folder
        if '.' not in file['name']:
            return False

        # check file extension
        if file['name'].split('.')[-1] not in self.config['ETL']['VALID_FILE_EXTENSIONS']:
            return False

        return True

    def process_file(self,
                     file,
                     filetype):

        # get file parser depending on file type
        match filetype:
            case 'pdf':
                parser = self.services["form_recognizer"]
            case 'docx':
                parser = self.word_parser
            case 'doc':
                parser = self.word_parser
            case 'txt':
                parser = self.text_parser
            case 'pptx':
                parser = self.powerpoint_parser
            case 'ppt':
                parser = self.powerpoint_parser

        # extract file content
        file_content = self.extract_file_content(file, parser)

        # split content into chunks
        docs = self.text_splitter.split([file_content])

        # embed chunks
        for ind, doc in enumerate(docs):

            self.embed_chunk(
                chunk=doc.page_content,
                chunk_id=file.id + '_content_' + str(ind),
                file_id=file.id
            )

        # update file obj to DB
        obj = File.get(self.services["cosmos_db"].session, file.id)
        obj.content = file_content
        obj.update(self.services["cosmos_db"].session)

    def store_file(self,
                   file,
                   email_id=None,
                   webUrl=None,
                   origin=None):

        # webUrl
        if webUrl is None:
            webUrl = file['webUrl']

        # download file bytes
        match origin:
            case 'onedrive':
                # download bytes from root onedrive
                file_bytes = self.services["microsoft_graph"].download_file_bytes(file['id'])
            case 'shared':
                # download bytes from the shared drive
                file_bytes = self.services["microsoft_graph"].download_shared_file_bytes(
                    drive_id=file['parentReference']['driveId'],
                    item_id=file['id']
                )
            case 'email':
                # download bytes from email attachment
                file_bytes = self.services["microsoft_graph"].download_email_attachment_bytes(
                    message_id=email_id,
                    attachment_id=file['id']
                )

        # store file bytes
        with open(self.config['ETL']['TMP_DATA_FOLDER'] + file['id'], 'wb') as f:
            f.write(file_bytes)

        # save file to DB
        obj = File(
            id=file['id'],
            name=file['name'],
            webUrl=webUrl,
            content=None,
            lastModifiedDateTime=file['lastModifiedDateTime'],
            size=file['size'],
            email_id=email_id,
            origin=origin
        )
        obj.save(self.services["cosmos_db"].session)

    def extract_file_content(self, file, parser):

        # read bytes from local storage
        with open(self.config['ETL']['TMP_DATA_FOLDER'] + file.id, 'rb') as f:
            file_bytes = f.read()

        # extract text
        file_content = parser.process_bytes(file_bytes)

        # delete file from local storage
        os.remove(self.config['ETL']['TMP_DATA_FOLDER'] + file.id)

        # pass the content to form recognizer
        return file_content

    def embed_chunk(self, chunk, chunk_id, file_id):

        # embed the file chunk
        embedding = self.services["azure_openai"].embeddings.embed_query(chunk)

        # save chunk to DB
        obj = FileEmbedding(
            chunk_id=chunk_id,
            file_id=file_id,
            chunk=chunk,
            embedding=embedding
        )
        obj.save(self.services["cosmos_db"].session)
