import logging
from langchain.text_splitter import CharacterTextSplitter


class TextSplitter:

    def __init__(self, config):

        # copy config
        self.config = config

        # initialize text splitter
        self.text_splitter = CharacterTextSplitter(
            separator="\n\n",
            chunk_size=self.config['TextSplitter']['CHUNK_SIZE'],
            chunk_overlap=self.config['TextSplitter']['CHUNK_OVERLAP'],
            length_function=len,
            is_separator_regex=False,
        )

        # log
        logging.info('Initialized TextSplitter')

    def split(self, texts, metadatas=None):
        return self.text_splitter.create_documents(
            texts,
            metadatas=metadatas
        )
