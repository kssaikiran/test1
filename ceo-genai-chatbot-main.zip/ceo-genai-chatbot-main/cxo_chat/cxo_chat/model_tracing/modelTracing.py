import json
import logging
import datetime
from cxo_chat.db.models import Trace


class ModelTracing:
    """
    Class for tracing the model responses over a defined dataset
    depending on the app configuration
    """

    def __init__(self, config, services):

        # copy config
        self.config = config

        # copy services
        self.services = services

        # log
        logging.info('Initialized ModelTracing')

    def run_experiment(self, dataset, task_detection, grounding):

        # save a copy of the config
        datetime_str = str(datetime.datetime.now()).replace(' ', '_')
        config_path = f'../data/configs/config_{datetime_str}.json'
        with open(config_path, 'w') as f:
            json.dump(self.config, f)

        # for each prompt in the dataset
        for obj in dataset.values():

            # get the prompt
            prompt = obj['prompt']

            # STEP 1 intent detection
            task = task_detection.get_task(prompt)

            # STEP 2 run the task
            response = task.run(
                query=prompt,
                grounding=grounding
            )

            # store the obj trace
            trace = Trace(
                prompt=prompt,
                response=response,
                expected_response=obj['expected_response'],
                config=config_path
            )
            trace.save(self.services["cosmos_db"].session)
