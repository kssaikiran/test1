import datetime

# sqlalchemy general
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import select

# data types
from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer
from pgvector.sqlalchemy import Vector

# sqlalchemy ORM base object
Base = declarative_base()


class Email(Base):
    __tablename__ = 'email'

    id = Column(String, primary_key=True)
    receivedDateTime = Column(DateTime)
    hasAttachments = Column(Boolean)
    subject = Column(String)
    conversationId = Column(String)
    isRead = Column(Boolean)
    content = Column(Text)
    sender_email = Column(String)
    sender_name = Column(String)
    webLink = Column(String)
    processed = Column(Boolean)

    def save(self, session):

        # check if email already exists
        email = session.query(Email).filter_by(id=self.id).first()

        # if email does not exist, add it
        if not email:
            session.add(self)
            session.commit()

    def delete(self, session):
        session.delete(self)
        session.commit()

    def update(self, session):
        session.commit()

    def exists(session, id):
        return session.query(Email).filter_by(id=id).first() is not None

    def get(session, id):
        return session.query(Email).filter_by(id=id).first()

    @staticmethod
    def get_unprocessed_emails(session):
        return session.query(Email).filter_by(processed=False).all()


class EmailEmbedding(Base):
    __tablename__ = 'email_embedding'

    chunk_id = Column(String, primary_key=True)
    email_id = Column(String)
    chunk = Column(Text)
    embedding = Column(Vector(1536))

    def save(self, session):

        # check if email already exists
        email_embedding = session.query(EmailEmbedding).filter_by(
            chunk_id=self.chunk_id
        ).first()

        # if email does not exist, add it
        if not email_embedding:
            session.add(self)
            session.commit()

    def delete(self, session):
        session.delete(self)
        session.commit()

    def get(session, chunk_id):
        return session.query(EmailEmbedding).filter_by(
            chunk_id=chunk_id
        ).first()

    @staticmethod
    def search(session,
               target_embedding,
               limit=5,
               weights={"semantic_similarity": 1, "relevance": 1}):

        # get similar chunks
        key_email_embeddings = session.scalars(
            select(EmailEmbedding)
            .order_by(EmailEmbedding.embedding.l2_distance(target_embedding))
            .limit(limit * 2)
        )

        # get similarity distances
        distances = list(session.scalars(
            select(EmailEmbedding.embedding.l2_distance(target_embedding))
            .order_by(EmailEmbedding.embedding.l2_distance(target_embedding))
            .limit(limit * 2)
        ))

        # combine them
        result = [{
            "chunk": ee.chunk,
            "web_url": Email.get(session, ee.email_id).webLink,
            "email_id": ee.email_id,
            "semantic_similarity": distances[ind],
            "relevance": (datetime.datetime.now() -
                          Email.get(session,
                                    ee.email_id).receivedDateTime).days
        } for ind, ee in enumerate(list(key_email_embeddings))]

        # deduplicate based on chunk
        seen_chunks = set()
        result = [x for x in result
                  if not (x["chunk"] in seen_chunks
                          or seen_chunks.add(x["chunk"]))]

        # get ranks according to similarity and relevance
        semantic_rank = [key * weights["semantic_similarity"] for
                         key, _ in
                         sorted(enumerate(result),
                         key=lambda x: x[1]['semantic_similarity'])]
        relevance_rank = [key * weights["relevance"] for
                          key, _ in
                          sorted(enumerate(result),
                          key=lambda x: x[1]['relevance'])]
        combined_rank = [sum(x) for x in zip(semantic_rank, relevance_rank)]

        # sort results according to the sum of ranks and return top limit
        result = [x for _, x in sorted(zip(combined_rank, result),
                  key=lambda x: x[0])][:limit]

        return result


class Task(Base):
    __tablename__ = 'task'

    name = Column(String, primary_key=True)
    description = Column(String)
    embedding = Column(Vector(1536))

    def save(self, session):

        # check if task already exists
        task = session.query(Task).filter_by(name=self.name).first()

        # if task does not exist, add it
        if not task:
            session.add(self)
            session.commit()

    def delete(self, session):
        session.delete(self)
        session.commit()

    def update(self, session):
        session.commit()

    def exists(session, name):
        return session.query(Task).filter_by(name=name).first() is not None

    def get(session, name):
        return session.query(Task).filter_by(name=name).first()

    @staticmethod
    def search(session, target_embedding):

        # get similar chunks
        return session.scalars(
            select(Task.name)
            .order_by(Task.embedding.l2_distance(target_embedding))
        ).first()


class Trace(Base):
    __tablename__ = 'trace'

    id = Column(Integer, primary_key=True)
    prompt = Column(String)
    response = Column(String)
    expected_response = Column(String)
    config = Column(String)

    def save(self, session):
        session.add(self)
        session.commit()

    def get_all(session):
        return session.query(Trace).all()


class File(Base):
    __tablename__ = 'file'

    id = Column(String, primary_key=True)
    name = Column(String)
    webUrl = Column(String)
    content = Column(Text)
    lastModifiedDateTime = Column(DateTime)
    size = Column(Integer)
    email_id = Column(String)
    origin = Column(String)

    def save(self, session):

        # check if file already exists
        file = session.query(File).filter_by(id=self.id).first()

        # if file does not exist, add it
        if not file:
            session.add(self)
            session.commit()

    def delete(self, session):
        session.delete(self)
        session.commit()

    def update(self, session):
        session.commit()

    def exists(session, id):
        return session.query(File).filter_by(id=id).first() is not None

    def get(session, id):
        return session.query(File).filter_by(id=id).first()

    @staticmethod
    def get_unprocessed_files(session):
        return session.query(File).filter_by(content=None).all()


class FileEmbedding(Base):
    __tablename__ = 'file_embedding'

    chunk_id = Column(String, primary_key=True)
    file_id = Column(String)
    chunk = Column(Text)
    embedding = Column(Vector(1536))

    def save(self, session):

        # check if file already exists
        file_embedding = session.query(FileEmbedding).filter_by(
            chunk_id=self.chunk_id
        ).first()

        # if file does not exist, add it
        if not file_embedding:
            session.add(self)
            session.commit()

    def delete(self, session):
        session.delete(self)
        session.commit()

    def get(session, chunk_id):
        return session.query(FileEmbedding).filter_by(
            chunk_id=chunk_id
        ).first()

    @staticmethod
    def search(session,
               target_embedding,
               limit=5,
               weights={"semantic_similarity": 1, "relevance": 1}):

        # get similar chunks
        key_file_embeddings = session.scalars(
            select(FileEmbedding)
            .order_by(FileEmbedding.embedding.l2_distance(target_embedding))
            .limit(limit * 2)
        )

        # get similarity distances
        distances = list(session.scalars(
            select(FileEmbedding.embedding.l2_distance(target_embedding))
            .order_by(FileEmbedding.embedding.l2_distance(target_embedding))
            .limit(limit * 2)
        ))

        # combine them
        result = [{
            "chunk": ee.chunk,
            "web_url": File.get(session, ee.file_id).webUrl,
            "file_id": ee.file_id,
            "semantic_similarity": distances[ind],
            "relevance": (datetime.datetime.now() -
                          File.get(session,
                                   ee.file_id).lastModifiedDateTime).days
        } for ind, ee in enumerate(list(key_file_embeddings))]

        # deduplicate based on chunk
        seen_chunks = set()
        result = [x for x in result
                  if not (x["chunk"] in seen_chunks
                          or seen_chunks.add(x["chunk"]))]

        # get ranks according to similarity and relevance
        semantic_rank = [key * weights["semantic_similarity"] for
                         key, _ in
                         sorted(enumerate(result),
                         key=lambda x: x[1]['semantic_similarity'])]
        relevance_rank = [key * weights["relevance"] for
                          key, _ in
                          sorted(enumerate(result),
                          key=lambda x: x[1]['relevance'])]
        combined_rank = [sum(x) for x in zip(semantic_rank, relevance_rank)]

        # sort results according to the sum of ranks and return top limit
        result = [x for _, x in sorted(zip(combined_rank, result),
                  key=lambda x: x[0])][:limit]

        return result
