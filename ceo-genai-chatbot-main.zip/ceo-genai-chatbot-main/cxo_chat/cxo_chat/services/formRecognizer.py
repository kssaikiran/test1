import io
import logging
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential


class FormRecognizer():
    """
    Class for interacting with the Azure Form Recognizer API
    over the official SDK.
    """

    def __init__(self, config, auth):

        # extract relevant config
        endpoint = config['AzureFormRecognizer']["ENDPOINT"]

        # build credential
        credential = AzureKeyCredential(config['AzureFormRecognizer']["KEY"])

        # create SDK client
        self.document_analysis_client = DocumentAnalysisClient(endpoint, credential)
        logging.info('Connected to Azure Form Recognizer')

    def process_file(self, file_path):

        # process pdf file
        with open(file_path, "rb") as f:
            poller = self.document_analysis_client.begin_analyze_document(
                "prebuilt-layout", document=f
            )
        result = poller.result()
        logging.info(f'Processed file {file_path}')

        return result.content

    def process_bytes(self, file_bytes):

        # process file bytes
        with io.BytesIO(file_bytes) as f:
            poller = self.document_analysis_client.begin_analyze_document(
                "prebuilt-layout", document=f
            )
        result = poller.result()
        logging.info('Processed file')

        return result.content
