import logging
import requests
from datetime import datetime, timedelta


class MicrosoftGraph:
    """
    Class for interacting with the Microsoft Graph API
    and providing a simple interface for getting emails,
    attachments, files, callendar events, chat messages, etc.
    """

    def __init__(self, config, auth):
        self.config = config
        self.auth = auth
        logging.info('Connected to Microsoft Graph')

    def _get_headers(self):
        return {
            'Authorization': 'Bearer ' + self.auth.get_token(),
            'Content-Type': 'application/json'
        }

    def query_graph(self, endpoint):
        headers = self._get_headers()

        # Make a GET request to retrieve the emails
        response = requests.get(endpoint, headers=headers)

        if response.status_code == 200:
            logging.info(f'Request {endpoint} to the Microsoft Graph was successful')
            messages = response.json()
            return messages

    # IS USED FOR DEVELOPMENT TO REDUCE THE NUMBER OF EMAILS
    def get_top_ten_emails(self):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_GET_MAIL']
        return self.query_graph(endpoint)

    def get_all_emails(self):
        # TODO: develop a method for getting all emails (metadata only?)
        return None

    # IS USED FOR DEVELOPMENT TO REDUCE THE NUMBER OF FILES
    def get_top_ten_onedrive_files(self, format):
        # Define the endpoint for getting messages
        return self.query_graph(
            self.config['MicrosoftGraph']['ENDPOINT_GET_ONEDRIVE'].format(format=format)
        )

    def get_all_onedrive_files(self):
        # TODO: develop a method for getting all files (metadata only?)
        return None

    def download_file_bytes(self, file_id):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_DOWNLOAD_FILE'].format(file_id=file_id)
        headers = self._get_headers()
        response = requests.get(endpoint, headers=headers)
        return response.content

    def download_email_attachment_bytes(self, message_id, attachment_id):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_DOWNLOAD_EMAIL_ATTACHMENT'].format(
            message_id=message_id,
            attachment_id=attachment_id
        )
        headers = self._get_headers()
        response = requests.get(endpoint, headers=headers)
        return response.content

    def download_shared_file_bytes(self, drive_id, item_id):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_DOWNLOAD_SHARED_FILE'].format(
            drive_id=drive_id,
            item_id=item_id
        )
        headers = self._get_headers()
        response = requests.get(endpoint, headers=headers)
        return response.content

    def get_top_ten_shared_files(self):
        # Define the endpoint for getting messages
        return self.query_graph(self.config['MicrosoftGraph']['ENDPOINT_GET_SHARED_FILES'])

    def get_attachments(self, message_id):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_GET_EMAIL_ATTACHMENTS'].format(
            message_id=message_id
        )
        return self.query_graph(endpoint)

    def search_emails(self, keyword="hello world"):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_SEARCH_EMAILS'].format(
            keyword=keyword
        )
        return self.query_graph(endpoint)

    def filter_emails(self, filter_statement="importance eq 'high'"):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_FILTER_EMAILS'].format(
            filter_statement=filter_statement
        )
        return self.query_graph(endpoint)

    def get_calendar_event(self, event_id):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_GET_CALENDAR_EVENT'].format(
            event_id=event_id
        )
        return self.query_graph(endpoint)

    def get_calendar_events_in_period(self, start_datetime, end_datetime):
        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_GET_CALENDAR'].format(
            start_datetime=start_datetime,
            end_datetime=end_datetime
        )
        return self.query_graph(endpoint)

    def get_next_calendar_event(self):

        # time now
        start_datetime = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'

        # time in 1 day
        end_datetime = (datetime.now() + timedelta(days=1)).\
            strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'

        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_GET_CALENDAR'].format(
            start_datetime=start_datetime,
            end_datetime=end_datetime
        ) + '&$top=1'
        return self.query_graph(endpoint)

    def get_calendar_events_from_today(self):

        # time now
        start_datetime = datetime.now().strftime("%Y-%m-%d") + 'T00:00:00.000Z'

        # time in 1 day
        end_datetime = datetime.now().strftime("%Y-%m-%d") + 'T23:59:59.999Z'

        # Define the endpoint for getting messages
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_GET_CALENDAR'].format(
            start_datetime=start_datetime,
            end_datetime=end_datetime
        )
        return self.query_graph(endpoint)

    def search_calendar_event(self, keyword):

        # Define the endpoint for search of the graph
        endpoint = self.config['MicrosoftGraph']['ENDPOINT_SEARCH']

        # Define the body of the request
        body = {
            "requests": [
                {
                    "entityTypes": [
                        "event"
                    ],
                    "query": {
                        "queryString": keyword
                    },
                    "from": 0,
                    "size": 5
                }
            ]
        }
        return requests.post(endpoint, headers=self._get_headers(), json=body).json()
