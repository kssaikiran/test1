import json
import base64
import logging
from azure.identity import DeviceCodeCredential
from msgraph import GraphServiceClient


class Auth:
    """
    Class for authenticating with the Microsoft Active Directory
    """

    def __init__(self, config):
        self.config = config
        self.authenticated = False
        self.access_token = None
        logging.info('Initialized Auth')

    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    # !!! CURRENTLY THIS ONE IS NOT USED !!!
    # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    def login(self):

        # create device code credential
        self.device_code_credential = DeviceCodeCredential(
            client_id=self.config['Auth']['CLIENT_ID'],
            tenant_id=self.config['Auth']['TENANT_ID'],
        )

        self.access_token = self.device_code_credential.get_token(
            self.config['Auth']['GRAPH_SCOPES'],
        )

        # create user client
        self.user_client = GraphServiceClient(
            self.device_code_credential,
            self.config['Auth']['GRAPH_SCOPES'].split(' '),
        )

        # toggle authenticated
        if self.user_client:
            logging.info('Authenticated')
            self.authenticated = True

    # !!!!!!!!!!!!!!!!!!!!!
    # !!! TO BE REMOVED !!!
    # !!!!!!!!!!!!!!!!!!!!!
    def fake_login(self):
        self.access_token = self.config['Auth']['AUTH_TOKEN']
        self.authenticated = True
        logging.info('Fake authenticated')

    def get_token(self):
        return self.access_token

    def get_user(self):
        _, b, __ = self.access_token.split('.')
        b64 = base64.b64decode(b + '===')
        return json.loads(b64)['unique_name']
