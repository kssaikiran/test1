import logging
from langchain.chat_models import AzureChatOpenAI
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.schema import HumanMessage


class AzureOpenAI:
    """
    Collection of 2 LangChain wrappers of
    Accenture's Azure LLM (gpt-4) and
    Embeding (ext-embedding-ada-002) model deployments
    """

    def __init__(self, config):

        # check that config is not None and is a dict
        if config is None:
            logging.error("Config is None")
            raise ValueError("Config is None")
        if not isinstance(config, dict):
            logging.error("Config is not a dict")
            raise ValueError("Config is not a dict")

        # check that config is properly formatted
        if 'AzureOpenAI' not in config.keys():
            logging.error("Config is missing Azure section")
            raise ValueError("Config is missing Azure section")
        if 'AZURE_API_TYPE' not in config['AzureOpenAI'].keys():
            logging.error("Config is missing Azure API type")
            raise ValueError("Config is missing Azure API type")
        if 'AZURE_API_BASE' not in config['AzureOpenAI'].keys():
            logging.error("Config is missing Azure API base")
            raise ValueError("Config is missing Azure API base")
        if 'AZURE_API_VERSION' not in config['AzureOpenAI'].keys():
            logging.error("Config is missing Azure API version")
            raise ValueError("Config is missing Azure API version")
        if 'AZURE_API_KEY' not in config['AzureOpenAI'].keys():
            logging.error("Config is missing Azure API key")
            raise ValueError("Config is missing Azure API key")
        if 'AZURE_LLM_DEPLOYMENT' not in config['AzureOpenAI'].keys():
            logging.error("Config is missing Azure API key")
            raise ValueError("Config is missing Azure API key")

        # llm model
        self.llm = AzureChatOpenAI(
            headers={
                "Ocp-Apim-Subscription-Key": config['AzureOpenAI']['AZURE_API_KEY'],
            },
            openai_api_base=config['AzureOpenAI']['AZURE_API_BASE'],
            openai_api_version=config['AzureOpenAI']['AZURE_API_VERSION'],
            deployment_name=config['AzureOpenAI']['AZURE_LLM_DEPLOYMENT'],
            openai_api_key=config['AzureOpenAI']['AZURE_API_KEY'],
            openai_api_type=config['AzureOpenAI']['AZURE_API_TYPE'],
        )
        logging.info("Azure LLM model loaded")

        # embeddings model
        self.embeddings = OpenAIEmbeddings(
            deployment=config['AzureOpenAI']['AZURE_EMBEDDINGS_DEPLOYMENT'],
            openai_api_key=config['AzureOpenAI']['AZURE_EMBEDDINGS_API_KEY'],
            openai_api_base=config['AzureOpenAI']['AZURE_EMBEDDINGS_API_BASE'],
            openai_api_type=config['AzureOpenAI']['AZURE_API_TYPE'],
        )
        logging.info("Azure embeddings model loaded")

    def simple_llm_request(self, text):
        logging.info("LLM request: {text}")
        response = self.llm([HumanMessage(content=text)]).content
        logging.info("LLM response: {response}")
        return response
