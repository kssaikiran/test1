# connect to cosmosdb using connection string
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


class CosmosDB:
    """
    Class for interacting with the CosmosDB database
    providing a session and engine SQLAlchemy objects
    for DB interaction over the ORM layer
    """

    def __init__(self, config, auth):

        # set up connection string
        connection_string = config['CosmosDB']['ACCESS_STRING'].format(
            db_name=config['CosmosDB']['DB_NAME'],
            db_password=config['CosmosDB']['DB_PASSWORD'],
            coordinator=config['CosmosDB']['COORDINATOR']
        )

        # connect to cosmosdb
        self.engine = create_engine(
            connection_string,
            connect_args={'options': '-csearch_path={}'.format(auth.get_user())})
        factory = sessionmaker(bind=self.engine)
        self.session = factory()
        logging.info('Connected to CosmosDB')
