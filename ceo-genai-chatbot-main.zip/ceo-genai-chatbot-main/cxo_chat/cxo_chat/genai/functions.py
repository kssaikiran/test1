import dateutil.parser
from cxo_chat.etl.utils import remove_non_ascii, extract_text


class Functions:

    function_descriptions = [
        {
            "name": "get_full_context",
            "description": "Get the context from user emails and files for the query",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "User query"
                    }
                },
                "required": ["query"]
            }
        },
        {
            "name": "get_email_context",
            "description": "Get the context from user emails for the query",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "User query"
                    }
                },
                "required": ["query"]
            }
        },
        {
            "name": "get_file_context",
            "description": "Get the context from user files for the query",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "User query"
                    }
                },
                "required": ["query"]
            }
        },
        {
            "name": "get_calendar_events_in_period",
            "description": "Get calendar events in a period",
            "parameters": {
                "type": "object",
                "properties": {
                    "start_datetime": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Start datetime"
                    },
                    "end_datetime": {
                        "type": "string",
                        "format": "date-time",
                        "description": "End datetime"
                    }
                },
                "required": ["start_datetime", "end_datetime"]
            }
        },
        {
            "name": "get_next_calendar_event",
            "description": "Get the next calendar event",
            "parameters": {
                "type": "object",
                "properties": {},
            }
        },
        {
            "name": "get_calendar_events_from_today",
            "description": "Get calendar events from today",
            "parameters": {
                "type": "object",
                "properties": {},
            }
        },
        {
            "name": "search_calendar_event",
            "description": "Search for a calendar event",
            "parameters": {
                "type": "object",
                "properties": {
                    "keyword": {
                        "type": "string",
                        "description": "Keyword to search for"
                    }
                },
                "required": ["keyword"]
            }
        }
    ]

    def __init__(self, config, services):

        # copy over config, services, and tools
        self.config = config
        self.services = services

    def _clean_search_event_data(self, data):

        if data is None or 'value' not in data:
            return []

        # clean the data
        data = data['value'][0]['hitsContainers'][0]['hits']
        clean_data = 'Events:\n'
        for event in data:

            # get event id
            event_id = event['hitId']

            # get event content
            content = self.services["microsoft_graph"].\
                get_calendar_event(event_id)
            if content is not None:
                content = content['body']['content']
            else:
                continue

            # clean the data
            event['start'] = event['resource']['start']['dateTime']
            event['end'] = event['resource']['end']['dateTime']
            event['content'] = extract_text(content)
            event['content'] = remove_non_ascii(event['content'])
            event['subject'] = remove_non_ascii(event['resource']['subject'])
            clean_data += f'start: {event["start"]} '
            clean_data += f'end: {event["end"]} '
            clean_data += f'subject: {event["subject"]} '
            clean_data += f'content: {event["content"]} '
            clean_data += '\n\n'

        return clean_data

    def _clean_event_data(self, data):

        if data is None or 'value' not in data:
            return []

        # clean the data
        data = data['value']
        clean_data = 'Events:\n'
        for event in data:
            event['start'] = event['start']['dateTime']
            event['end'] = event['end']['dateTime']
            event['content'] = extract_text(event['body']['content'])
            event['content'] = remove_non_ascii(event['content'])
            event['subject'] = remove_non_ascii(event['subject'])
            clean_data += f'start: {event["start"]} '
            clean_data += f'end: {event["end"]} '
            clean_data += f'subject: {event["subject"]} '
            clean_data += f'content: {event["content"]} '
            clean_data += '\n\n'

        return clean_data

    def get_full_context(self, params):
        return self.services["grounding"].get_full_context(params["query"])

    def get_email_context(self, params):
        return self.services["grounding"].get_email_context(params["query"])

    def get_file_context(self, params):
        return self.services["grounding"].get_file_context(params["query"])

    def get_calendar_events_in_period(self, params):

        # properly format start and end datetimes
        start_datetime = dateutil.parser.parse(params["start_datetime"])
        start_datetime = start_datetime.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'
        end_datetime = dateutil.parser.parse(params["end_datetime"])
        end_datetime = end_datetime.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'

        # fetch data
        data = self.services["microsoft_graph"].\
            get_calendar_events_in_period(start_datetime, end_datetime)
        return self._clean_event_data(data)

    def get_next_calendar_event(self):
        data = self.services["microsoft_graph"].get_next_calendar_event()
        return self._clean_event_data(data)

    def get_calendar_events_from_today(self):
        data = self.services["microsoft_graph"].get_calendar_events_from_today()
        return self._clean_event_data(data)

    def search_calendar_event(self, params):
        data = self.services["microsoft_graph"].search_calendar_event(params["keyword"])
        return self._clean_search_event_data(data)

    def run_function(self, function_name, params):

        match function_name:
            case "get_full_context":
                return self.get_full_context(params)
            case "get_email_context":
                return self.get_email_context(params)
            case "get_file_context":
                return self.get_file_context(params)
            case "get_calendar_events_in_period":
                return self.get_calendar_events_in_period(params)
            case "get_next_calendar_event":
                return self.get_next_calendar_event()
            case "get_calendar_events_from_today":
                return self.get_calendar_events_from_today()
            case "search_calendar_event":
                return self.search_calendar_event(params)
            case _:
                raise ValueError(f"Function {function_name} not found")
