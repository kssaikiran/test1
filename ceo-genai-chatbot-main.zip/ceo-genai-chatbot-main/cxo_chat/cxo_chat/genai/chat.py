import openai
from datetime import date


class Chat:
    def __init__(self, config, functions):

        # copy over config and services
        self.config = config
        self.functions = functions

        # OpenAI API config
        openai.api_key = config['AzureOpenAI']['AZURE_API_KEY']
        openai.api_version = config['AzureOpenAI']['AZURE_API_VERSION']
        openai.api_type = config['AzureOpenAI']['AZURE_API_TYPE']
        openai.api_base = config['AzureOpenAI']['AZURE_API_BASE']

        # message history
        self.messages = []

        # add system prompt
        self.messages.append({
            "role": "system",
            "content": config['GenAI']['SYSTEM_PROMPT'].format(
                today_date=date.today().strftime("%Y-%m-%d")
            )
        })

    def call_llm(self):

        # call LLM
        response_message = openai.ChatCompletion.create(
            engine=self.config['AzureOpenAI']['AZURE_LLM_DEPLOYMENT'],
            messages=self.messages,
            functions=self.functions.function_descriptions,
            function_call="auto",
        )["choices"][0]["message"]

        return response_message

    def run(self, user_message, verbose=False):

        # add user message to message history
        self.messages.append({
            "role": "user",
            "content": user_message
        })
        return self.call_llm()
