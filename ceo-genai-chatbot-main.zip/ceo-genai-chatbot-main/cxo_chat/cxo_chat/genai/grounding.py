import logging
from cxo_chat.db.models import FileEmbedding, EmailEmbedding


class Grounding:
    """
    Class for grounding the query (either on the chunks from the DB
    or on the entities from the Graph API)
    """

    def __init__(self, config, services):

        # copy config
        self.config = config

        # copy services
        self.services = services

        # log
        logging.info('Initialized Grounding')

    def get_context(self, query, scopes):

        # initialize context
        context = ''

        # scope limit
        scope_limit = int(16000 / len(scopes))

        # embed the query
        query_embedding = self.services["azure_openai"].embeddings.embed_query(query)

        for scope in scopes:

            # search for the most similar chunks
            scope_context_items = scope.search(
                session=self.services["cosmos_db"].session,
                target_embedding=query_embedding,
                limit=self.config['Grounding']['NUMBER_OF_CHUNKS'],
                weights=self.config['Grounding']['WEIGHTS']
            )

            # serialize output
            scope_context = '\n'.join([str({
                    "web_url": a["web_url"],
                    "chunk": a["chunk"]
                }) for a in scope_context_items])

            # cut it
            scope_context = scope_context[:scope_limit] + '\n'
            logging.info(f'Scope {scope.__str__} context: {scope_context}')

            # add to context
            context += scope_context

        return context

    def get_full_context(self, query):
        return self.get_context(query=query, scopes=[FileEmbedding, EmailEmbedding])

    def get_email_context(self, query):
        return self.get_context(query=query, scopes=[EmailEmbedding])

    def get_file_context(self, query):
        return self.get_context(query=query, scopes=[FileEmbedding])
