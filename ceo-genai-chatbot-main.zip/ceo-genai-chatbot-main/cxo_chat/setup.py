from setuptools import setup

setup(
    name='cxo_chat',
    version='0.1.0',    
    description='A package for CXO chatbot backend functionality',
    author='Dzmitry Ashkinadze',
    author_email='dzmitry.ashkinadze@accenture.com',
    packages=['cxo_chat'],
    install_requires=[
        'langchain',                     
    ]
)