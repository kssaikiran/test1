"""Unit tests for taskDetection class"""

# generic imports
# import pytest

# import modules to test
from cxo_chat.genai.taskDetection import TaskDetection


def test_module_imports():
    """Test module imports"""
    assert TaskDetection
