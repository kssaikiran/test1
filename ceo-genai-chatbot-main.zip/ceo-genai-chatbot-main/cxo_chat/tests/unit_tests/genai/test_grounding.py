"""Unit tests for Grounding class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.genai.grounding import Grounding

def test_module_imports():
    """Test module imports"""
    assert Grounding