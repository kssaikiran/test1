"""Unit tests for utils functions"""

# generic imports
import pytest

# import modules to test
from cxo_chat.etl.utils import remove_non_ascii, extract_text