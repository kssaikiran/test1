"""Unit tests for ChatProcessor class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.etl.chatProcessor import ChatProcessor

def test_module_imports():
    """Test module imports"""
    assert ChatProcessor