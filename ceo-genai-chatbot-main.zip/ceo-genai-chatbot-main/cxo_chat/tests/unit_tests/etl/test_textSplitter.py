"""Unit tests for TextSplitter class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.etl.textSplitter import TextSplitter

def test_module_imports():
    """Test module imports"""
    assert TextSplitter