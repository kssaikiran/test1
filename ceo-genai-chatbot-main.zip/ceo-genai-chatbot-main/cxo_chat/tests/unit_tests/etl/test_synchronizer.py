"""Unit tests for Synchronizer class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.etl.synchronizer import Synchronizer

def test_module_imports():
    """Test module imports"""
    assert Synchronizer