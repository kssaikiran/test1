"""Unit tests for CalendarProcessor class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.etl.calendarProcessor import CalendarProcessor

def test_module_imports():
    """Test module imports"""
    assert CalendarProcessor