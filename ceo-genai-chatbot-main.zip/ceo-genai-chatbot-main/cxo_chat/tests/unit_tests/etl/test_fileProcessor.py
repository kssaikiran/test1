"""Unit tests for fileProcessor class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.etl.fileProcessor import FileProcessor

def test_module_imports():
    """Test module imports"""
    assert FileProcessor