"""Unit tests for DB models"""

# generic imports
# import pytest

# import modules to test
from cxo_chat.db.models import Email
from cxo_chat.db.models import EmailEmbedding


def test_module_imports():
    """Test module imports"""
    assert Email
    assert EmailEmbedding
