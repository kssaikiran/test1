"""Unit tests for MicrosoftGraph class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.services.microsoftGraph import MicrosoftGraph

def test_module_imports():
    """Test module imports"""
    assert MicrosoftGraph