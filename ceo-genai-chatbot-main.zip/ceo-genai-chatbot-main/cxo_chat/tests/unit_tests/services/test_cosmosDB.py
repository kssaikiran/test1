"""Unit tests for CosmosDB class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.services.cosmosDB import CosmosDB

def test_module_imports():
    """Test module imports"""
    assert CosmosDB