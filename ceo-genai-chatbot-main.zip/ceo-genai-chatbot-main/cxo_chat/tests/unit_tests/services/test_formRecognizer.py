"""Unit tests for FormRecognizer class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.services.formRecognizer import FormRecognizer

def test_module_imports():
    """Test module imports"""
    assert FormRecognizer