"""Unit tests for Auth class"""

# generic imports
import pytest

# import modules to test
from cxo_chat.services.auth import Auth

def test_module_imports():
    """Test module imports"""
    assert Auth